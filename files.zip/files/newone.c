#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(){
	
	FILE *fp,*fp1;
	
	int arr[10];
	int i;
	
	
	
	fp=fopen("C:/Users/Srivalli/OneDrive/Desktop/Classroom sem 2/C/files/file1.txt.txt","r");
	printf("%d",ftell(fp));
	
	fseek(fp,5,1);
	//0- from the beginning, 1- current position, 2- from the end
	//5 - 5 jumps(5-current position)
	//if -5 is given , then jump in backward direcn

	char ch=fgetc(fp);
	

	fclose(fp);
	
}
