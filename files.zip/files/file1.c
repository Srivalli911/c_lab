#include<stdio.h>
#include<stdlib.h>

int main(){
	
	FILE *fp;
	
	fp=fopen("C:/Users/Srivalli/OneDrive/Desktop/Classroom sem 2/C/files/file1.txt.txt","r");
	//while copying as path ,change every slash to forward slash
	
	if(fp==NULL)
	{
		printf("file not opened\n");
	}
	
	char ch;
	
	ch=fgetc(fp);
	printf(" first char is %c\n",ch); //to get the 1st char fro the file
	
	ch=fgetc(fp);
	
	while(ch!=EOF)
	{
	    printf("%c",ch);
	    ch=fgetc(fp);
	}

	
	fclose(fp);
	
	
}
